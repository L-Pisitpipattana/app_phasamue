class vocab{
  late final String title;
  late final String url;

  vocab(this.title, this.url);
}