package com.example.app_phasamue

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
